﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Parcial2.Models
{
    public class Cliente
    {
        public String Nombre { get; set; }
        public String Apellido { get; set; }
        public Decimal Sueldo { get; set; }
    }
}